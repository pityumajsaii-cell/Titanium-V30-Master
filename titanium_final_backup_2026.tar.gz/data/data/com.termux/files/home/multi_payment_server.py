#!/usr/bin/env python3
import os, threading, subprocess, time, socket
from dotenv import load_dotenv
from flask import Flask, jsonify, request
import stripe, paypalrestsdk

load_dotenv(os.path.expanduser("~/.env"))

app = Flask(__name__)

# ===== Stripe =====
STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY")
STRIPE_PUBLISHABLE_KEY = os.getenv("STRIPE_PUBLISHABLE_KEY")
stripe.api_key = STRIPE_SECRET_KEY

# ===== PayPal =====
PAYPAL_CLIENT_ID = os.getenv("PAYPAL_CLIENT_ID")
PAYPAL_CLIENT_SECRET = os.getenv("PAYPAL_CLIENT_SECRET")
paypalrestsdk.configure({
    "mode": "sandbox",
    "client_id": PAYPAL_CLIENT_ID,
    "client_secret": PAYPAL_CLIENT_SECRET
})

# ===== Gemini / Kripto =====
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# ===== Stripe fizetés =====
@app.route("/stripe/create_payment", methods=["POST"])
def stripe_create_payment():
    data = request.json
    amount = data.get("amount", 1000)
    try:
        intent = stripe.PaymentIntent.create(
            amount=amount,
            currency="usd",
            payment_method_types=["card"]
        )
        return jsonify({"payment_intent_id": intent.id, "client_secret": intent.client_secret})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# ===== PayPal fizetés =====
@app.route("/paypal/create_payment", methods=["POST"])
def paypal_create_payment():
    data = request.json
    amount = data.get("amount", "10.00")
    payment = paypalrestsdk.Payment({
        "intent": "sale",
        "payer": {"payment_method": "paypal"},
        "transactions": [{"amount": {"total": amount, "currency": "USD"}}],
        "redirect_urls": {
            "return_url": "http://localhost:3001/paypal/execute",
            "cancel_url": "http://localhost:3001/paypal/cancel"
        }
    })
    if payment.create():
        return jsonify({"paymentID": payment.id, "approval_url": payment.links[1].href})
    else:
        return jsonify({"error": payment.error}), 400

# ===== Crypto fizetés =====
@app.route("/crypto/create_payment", methods=["POST"])
def crypto_create_payment():
    return jsonify({"message": "Kripto fizetés modul készen áll"})

# ===== Index =====
@app.route("/")
def index():
    return jsonify({"message": "Profi Multi-Payment SaaS OS él", "stripe_key": STRIPE_PUBLISHABLE_KEY})

def run_flask():
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "3001")))

def run_tunnel():
    time.sleep(3)
    try:
        proc = subprocess.Popen(["lt", "--port", os.getenv("PORT", "3001"), "--print-requests"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        for line in iter(proc.stdout.readline, b''):
            line = line.decode()
            if "https://" in line:
                url = line.split()[0]
                print(f"\n📡 Publikus URL: {url}\n")
                break
    except Exception as e:
        print(f"Tunnel hiba: {e}")

# ===== Szálak =====
threading.Thread(target=run_flask, daemon=True).start()
threading.Thread(target=run_tunnel, daemon=True).start()

while True:
    time.sleep(1)
